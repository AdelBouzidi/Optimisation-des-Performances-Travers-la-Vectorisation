#include <immintrin.h>
#include <iostream>
#include <algorithm>

void ssgemm(
    int m, int n, int k,
    float alpha,
    float ** A,
    float ** B,
    float beta,
    float ** C)
{
    int r, c, d;
    int rr, cc, dd;
    const int Tr = 16;
    const int Tc = 16;
    const int Td = 16;

    for (dd = 0; dd < k; dd += Td)
    {
        for (cc = 0; cc < n; cc += Tc)
        {
            for (rr = 0; rr < m; rr += Tr)
            {
                for (c = cc; c < std::min(cc + Tc, n); ++c)
                {
                    for (r = rr; r < std::min(rr + Tr, m); ++r)
                    {
                        __m256 t8 = _mm256_setzero_ps(); // accumulateur SIMD
                        int d_vec = dd;

                        // partie vectorisée
                        for (; d_vec <= std::min(dd + Td, k) - 8; d_vec += 8)
                        {
                            __m256 a8 = _mm256_loadu_ps(&A[r][d_vec]);      // A[r][d_vec..d_vec+7]
                            __m256 b8 = _mm256_set_ps(
                                B[d_vec + 7][c], B[d_vec + 6][c],
                                B[d_vec + 5][c], B[d_vec + 4][c],
                                B[d_vec + 3][c], B[d_vec + 2][c],
                                B[d_vec + 1][c], B[d_vec + 0][c]);           // colonne B en scalaires
                            __m256 mul = _mm256_mul_ps(a8, b8);
                            t8 = _mm256_add_ps(t8, mul);
                        }

                        // réduction SIMD vers scalaire
                        float tmp[8];
                        _mm256_storeu_ps(tmp, t8);
                        float t = tmp[0] + tmp[1] + tmp[2] + tmp[3] +
                                  tmp[4] + tmp[5] + tmp[6] + tmp[7];

                        // reste scalaire (si Td pas multiple de 8)
                        for (; d_vec < std::min(dd + Td, k); ++d_vec)
                        {
                            t += A[r][d_vec] * B[d_vec][c];
                        }

                        // mise à jour finale de C
                        C[r][c] = C[r][c] * beta + alpha * t;
                    }
                }
            }
        }
    }
}

